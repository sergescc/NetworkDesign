

CONST_ERROR = "[\033[31m Error \033[m]"
